//
//  StatesApp.swift
//  States
//
//  Created by Andrew Kim on 4/5/24.
//

import SwiftUI

@main
struct StatesApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
