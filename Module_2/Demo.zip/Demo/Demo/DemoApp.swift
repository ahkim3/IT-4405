//
//  DemoApp.swift
//  Demo
//
//  Created by Andrew Kim on 1/26/24.
//

import SwiftUI

@main
struct DemoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
