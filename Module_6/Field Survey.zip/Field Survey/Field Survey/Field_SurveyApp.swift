//
//  Field_SurveyApp.swift
//  Field Survey
//
//  Created by Andrew Kim on 2/23/24.
//

import SwiftUI

@main
struct Field_SurveyApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
