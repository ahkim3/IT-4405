//
//  Photos_Codable_and_JSON_DecodingApp.swift
//  Photos Codable and JSON Decoding
//
//  Created by Andrew Kim on 4/18/24.
//

import SwiftUI

@main
struct Photos_Codable_and_JSON_DecodingApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
