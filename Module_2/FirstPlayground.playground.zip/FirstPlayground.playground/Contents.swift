import UIKit

var greeting = "Hello, playground"
print(greeting)

for index in 1..<5 {
    print(index)
}

let myList = ["apple", "oranges"]
for thing in myList {
    print(thing)
}
