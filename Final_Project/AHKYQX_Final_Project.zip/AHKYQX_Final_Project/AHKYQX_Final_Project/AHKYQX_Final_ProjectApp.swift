//
//  AHKYQX_Final_ProjectApp.swift
//  AHKYQX_Final_Project
//
//  Created by Andrew Kim on 5/5/24.
//

import SwiftUI

@main
struct AHKYQX_Final_ProjectApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
