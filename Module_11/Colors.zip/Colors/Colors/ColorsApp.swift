//
//  ColorsApp.swift
//  Colors
//
//  Created by Andrew Kim on 4/5/24.
//

import SwiftUI

@main
struct ColorsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
